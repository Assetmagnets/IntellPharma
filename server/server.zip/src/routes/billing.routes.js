const express = require('express');
const prisma = require('../lib/prisma');
const { authenticate, authorize, requireBranchAccess, logAudit } = require('../middleware/auth');
const { requireFeature } = require('./subscription.routes');

const router = express.Router();

// Generate invoice number
// Generate invoice number (Atomic)
const generateInvoiceNumber = async (tx, branchId) => {
    const date = new Date();
    const yearMonth = `${date.getFullYear()}${String(date.getMonth() + 1).padStart(2, '0')}`;
    const branchPrefix = branchId ? branchId.substring(0, 4).toUpperCase() : 'DEF';
    const prefix = `INV-${branchPrefix}-${yearMonth}`;

    // Atomic increment using upsert
    // This ensures that even if called in parallel, the database locks the row and increments safely
    const sequence = await tx.invoiceSequence.upsert({
        where: {
            branchId_yearMonth: {
                branchId,
                yearMonth
            }
        },
        update: {
            seq: { increment: 1 }
        },
        create: {
            branchId,
            yearMonth,
            seq: 1
        }
    });

    // Format: INV202401000001
    return `${prefix}${String(sequence.seq).padStart(6, '0')}`;
};

// Calculate GST
const calculateGST = (amount, gstRate, isInterState = false) => {
    const gstAmount = (amount * gstRate) / 100;
    if (isInterState) {
        return { cgst: 0, sgst: 0, igst: gstAmount };
    }
    return { cgst: gstAmount / 2, sgst: gstAmount / 2, igst: 0 };
};

// Create new invoice
router.post('/:branchId', authenticate, authorize('OWNER', 'MANAGER', 'PHARMACIST', 'BILLING_STAFF'), requireBranchAccess, async (req, res) => {
    try {
        const { branchId } = req.params;
        const {
            customerName,
            customerPhone,
            customerAddress,
            items,
            discountPercent = 0, // Changed: now accepts percentage
            paymentMethod = 'CASH',
            isInterState = false,
            notes
        } = req.body;

        if (!items || items.length === 0) {
            return res.status(400).json({ error: 'Invoice must have at least one item.' });
        }

        const result = await prisma.$transaction(async (tx) => {
            // Pass transaction object 'tx' so the increment happens inside the same robust transaction
            const invoiceNumber = await generateInvoiceNumber(tx, branchId);

            let subtotal = 0;
            let totalCgst = 0;
            let totalSgst = 0;
            let totalIgst = 0;
            const invoiceItems = [];

            // Process each item
            for (const item of items) {
                const product = await tx.product.findUnique({ where: { id: item.productId } });

                if (!product) {
                    throw new Error(`Product not found: ${item.productId}`);
                }

                const itemSubtotal = parseFloat(product.mrp) * item.quantity;

                // NEW LOGIC: Distribute global discount to item to reduce Taxable Amount
                const globalDiscountPercent = parseFloat(discountPercent || 0);
                const itemDiscountAmount = (itemSubtotal * globalDiscountPercent) / 100;

                const taxableAmount = itemSubtotal - itemDiscountAmount;
                const gst = calculateGST(taxableAmount, parseFloat(product.gstRate), isInterState);
                const itemTotal = taxableAmount + gst.cgst + gst.sgst + gst.igst;

                subtotal += itemSubtotal;
                totalCgst += gst.cgst;
                totalSgst += gst.sgst;
                totalIgst += gst.igst;

                invoiceItems.push({
                    productId: product.id,
                    productName: product.name,
                    quantity: item.quantity,
                    unitPrice: product.mrp,
                    discount: itemDiscountAmount, // Store the calculated amount
                    gstRate: product.gstRate,
                    cgst: gst.cgst,
                    sgst: gst.sgst,
                    igst: gst.igst,
                    total: itemTotal
                });

                // Atomic Update: Decrement only if sufficient stock exists
                // We use updateMany because it allows checking 'quantity >= requestedQty' in permission clause
                const updateResult = await tx.product.updateMany({
                    where: {
                        id: product.id,
                        quantity: {
                            gte: item.quantity // Atomic check
                        }
                    },
                    data: {
                        quantity: {
                            decrement: item.quantity // Atomic decrement
                        }
                        // Note: We cannot conditionally toggle 'isActive' here easily.
                        // It is better to have 0 stock than to have negative stock.
                    }
                });

                if (updateResult.count === 0) {
                    // Refetch to give helpful error message
                    const currentProduct = await tx.product.findUnique({ where: { id: item.productId } });
                    const available = currentProduct ? Number(currentProduct.quantity) : 0;
                    throw new Error(`Insufficient stock for ${product.name}. Available: ${available}, Requested: ${item.quantity}`);
                }
            }

            // Calculate overall discount from percentage
            const overallDiscountAmount = (subtotal * parseFloat(discountPercent)) / 100;
            const totalAmount = subtotal - overallDiscountAmount + totalCgst + totalSgst + totalIgst;

            // Create invoice with items
            const invoice = await tx.invoice.create({
                data: {
                    invoiceNumber,
                    customerName,
                    customerPhone,
                    customerAddress,
                    subtotal,
                    discountAmount: overallDiscountAmount, // Store calculated amount from percentage
                    cgstAmount: totalCgst,
                    sgstAmount: totalSgst,
                    igstAmount: totalIgst,
                    totalAmount,
                    paymentMethod,
                    notes,
                    branchId,
                    createdById: req.user.id,
                    items: {
                        create: invoiceItems
                    }
                },
                include: {
                    items: true,
                    branch: {
                        select: {
                            name: true,
                            address: true,
                            gstNumber: true,
                            phone: true
                        }
                    }
                }
            });

            return invoice;
        });

        await logAudit(req.user.id, branchId, 'CREATE', 'Invoice', result.id,
            `Created invoice: ${result.invoiceNumber}, Amount: ${result.totalAmount}`, req.ip);

        res.status(201).json(result);
    } catch (error) {
        console.error('Create invoice error:', error);
        res.status(500).json({ error: error.message || 'Failed to create invoice.' });
    }
});

// Get all invoices for a branch
router.get('/:branchId', authenticate, requireBranchAccess, async (req, res) => {
    try {
        const { branchId } = req.params;
        const { startDate, endDate, status, page = 1, limit = 20 } = req.query;

        let where = { branchId };

        if (startDate && endDate) {
            where.createdAt = {
                gte: new Date(startDate),
                lte: new Date(endDate)
            };
        }

        if (status) {
            where.status = status;
        }

        const skip = (parseInt(page) - 1) * parseInt(limit);

        const [invoices, total] = await Promise.all([
            prisma.invoice.findMany({
                where,
                include: {
                    createdBy: {
                        select: { name: true }
                    }
                },
                orderBy: { createdAt: 'desc' },
                skip,
                take: parseInt(limit)
            }),
            prisma.invoice.count({ where })
        ]);

        res.json({
            invoices,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total,
                pages: Math.ceil(total / parseInt(limit))
            }
        });
    } catch (error) {
        console.error('Get invoices error:', error);
        res.status(500).json({ error: 'Failed to fetch invoices.' });
    }
});

// Get single invoice
router.get('/:branchId/:invoiceId', authenticate, requireBranchAccess, async (req, res) => {
    try {
        const { invoiceId } = req.params;

        const invoice = await prisma.invoice.findUnique({
            where: { id: invoiceId },
            include: {
                items: {
                    include: {
                        product: {
                            select: { barcode: true, hsnCode: true }
                        }
                    }
                },
                branch: true,
                createdBy: {
                    select: { name: true, email: true }
                },
                returns: true
            }
        });

        if (!invoice) {
            return res.status(404).json({ error: 'Invoice not found.' });
        }

        res.json(invoice);
    } catch (error) {
        console.error('Get invoice error:', error);
        res.status(500).json({ error: 'Failed to fetch invoice.' });
    }
});

// Process return
router.post('/:branchId/:invoiceId/return', authenticate, authorize('OWNER', 'MANAGER', 'BILLING_STAFF'), requireBranchAccess, async (req, res) => {
    try {
        const { branchId, invoiceId } = req.params;
        const { reason, refundAmount, returnItems } = req.body;

        const result = await prisma.$transaction(async (tx) => {
            const invoice = await tx.invoice.findUnique({
                where: { id: invoiceId },
                include: { items: true }
            });

            if (!invoice) {
                throw new Error('Invoice not found.');
            }

            // Restore stock for returned items
            for (const returnItem of returnItems) {
                const invoiceItem = invoice.items.find(i => i.id === returnItem.invoiceItemId);
                if (invoiceItem) {
                    await tx.product.update({
                        where: { id: invoiceItem.productId },
                        data: { quantity: { increment: returnItem.quantity } }
                    });
                }
            }

            // Create return record
            const returnRecord = await tx.return.create({
                data: {
                    invoiceId,
                    reason,
                    refundAmount: parseFloat(refundAmount),
                    creditNote: `CN-${invoice.invoiceNumber}`
                }
            });

            // Update invoice status
            await tx.invoice.update({
                where: { id: invoiceId },
                data: { status: 'REFUNDED' }
            });

            return returnRecord;
        });

        await logAudit(req.user.id, branchId, 'RETURN', 'Invoice', invoiceId,
            `Processed return. Refund: ${refundAmount}`, req.ip);

        res.json(result);
    } catch (error) {
        console.error('Process return error:', error);
        res.status(500).json({ error: error.message || 'Failed to process return.' });
    }
});

// Helper to safely convert Decimal to Number
const toNum = (val) => {
    if (!val) return 0;
    if (val && val.toNumber) return val.toNumber();
    return Number(val) || 0;
};

// Get sales summary
router.get('/:branchId/reports/summary', authenticate, authorize('OWNER', 'MANAGER'), requireBranchAccess, async (req, res) => {
    try {
        const { branchId } = req.params;
        const { startDate, endDate } = req.query;

        const where = { branchId };
        if (startDate && endDate) {
            // Parse dates as UTC explicitly to avoid server timezone issues
            const startObj = new Date(startDate + 'T00:00:00.000Z');
            const endObj = new Date(endDate + 'T23:59:59.999Z');

            where.createdAt = {
                gte: startObj,
                lte: endObj
            };
        }

        const [summary, paymentBreakdown] = await Promise.all([
            prisma.invoice.aggregate({
                where,
                _sum: {
                    totalAmount: true,
                    cgstAmount: true,
                    sgstAmount: true,
                    igstAmount: true,
                    discountAmount: true
                },
                _count: true
            }),
            prisma.invoice.groupBy({
                by: ['paymentMethod'],
                where,
                _sum: { totalAmount: true },
                _count: true
            })
        ]);

        res.json({
            totalSales: toNum(summary._sum.totalAmount),
            totalGST: toNum(summary._sum.cgstAmount) + toNum(summary._sum.sgstAmount) + toNum(summary._sum.igstAmount),
            totalDiscount: toNum(summary._sum.discountAmount),
            invoiceCount: summary._count,
            paymentBreakdown: paymentBreakdown.map(p => ({
                method: p.paymentMethod,
                total: p._sum.totalAmount,
                count: p._count
            }))
        });
    } catch (error) {
        console.error('Sales summary error:', error);
        res.status(500).json({ error: 'Failed to fetch sales summary.' });
    }
});

// Get advanced report data
router.get('/:branchId/reports/advanced', authenticate, authorize('OWNER', 'MANAGER'), requireBranchAccess, requireFeature('analytics'), async (req, res) => {
    try {
        const { branchId } = req.params;
        const { startDate, endDate } = req.query;

        // Parse dates as UTC explicitly to avoid server timezone issues
        const startObj = new Date(startDate + 'T00:00:00.000Z');
        const endObj = new Date(endDate + 'T23:59:59.999Z');

        const dateFilter = {
            createdAt: {
                gte: startObj,
                lte: endObj
            }
        };

        const [
            summary,
            paymentBreakdown,
            topProducts,
            inventoryValuation
        ] = await Promise.all([
            // 1. Financial Summary
            prisma.invoice.aggregate({
                where: { branchId, ...dateFilter },
                _sum: {
                    totalAmount: true,
                    discountAmount: true,
                    cgstAmount: true,
                    sgstAmount: true,
                    igstAmount: true
                },
                _count: true
            }),
            // 2. Payment Method Breakdown
            prisma.invoice.groupBy({
                by: ['paymentMethod'],
                where: { branchId, ...dateFilter },
                _sum: { totalAmount: true },
                _count: true
            }),
            // 3. Top Selling Products
            prisma.invoiceItem.groupBy({
                by: ['productName'],
                where: {
                    invoice: { branchId, ...dateFilter }
                },
                _sum: {
                    quantity: true,
                    total: true
                },
                orderBy: {
                    _sum: { quantity: 'desc' }
                },
                take: 5
            }),
            // 4. Current Inventory Value (Snapshop - not historical)
            prisma.product.aggregate({
                where: { branchId, isActive: true },
                _sum: {
                    purchasePrice: true, // This is unit price, need to multiply in app or here if possible. 
                    // Prisma aggregate doesn't support multiplication directly easily without raw query.
                    // We'll estimate or just count items for now. 
                },
                _count: true
            })
        ]);

        // Calculate accurate inventory value
        // Since we can't easily do sum(qty * price) in simple prisma aggregate, let's do a raw query for it or fetch all.
        // For a report, accuracy matters. Let's use raw query for inventory value.
        const stockValueResult = await prisma.$queryRaw`
            SELECT SUM("quantity" * "purchasePrice") as "totalValue" 
            FROM "Product" 
            WHERE "branchId" = ${branchId} AND "isActive" = true
        `;
        const currentStockValue = stockValueResult[0]?.totalValue || 0;

        res.json({
            period: { startDate, endDate },
            financials: {
                totalSales: toNum(summary._sum.totalAmount),
                totalGST: toNum(summary._sum.cgstAmount) + toNum(summary._sum.sgstAmount) + toNum(summary._sum.igstAmount),
                totalDiscount: toNum(summary._sum.discountAmount),
                invoiceCount: summary._count
            },
            paymentBreakdown: paymentBreakdown.map(p => ({
                method: p.paymentMethod,
                total: p._sum.totalAmount,
                count: p._count
            })),
            topProducts: topProducts.map(p => ({
                name: p.productName,
                quantity: p._sum.quantity,
                revenue: p._sum.total
            })),
            inventory: {
                currentValue: currentStockValue,
                productCount: inventoryValuation._count
            }
        });

    } catch (error) {
        console.error('Advanced report error:', error);
        res.status(500).json({ error: 'Failed to generate report.' });
    }
});

module.exports = router;
