const express = require('express');
const prisma = require('../lib/prisma');
const { authenticate, authorize } = require('../middleware/auth');
const { PLANS } = require('./subscription.routes');

const router = express.Router();

// Initialize Stripe with secret key
const stripeSecretKey = process.env.STRIPE_SECRET_KEY;
let stripe = null;

if (stripeSecretKey) {
    stripe = require('stripe')(stripeSecretKey);
} else {
    console.warn('⚠️  STRIPE_SECRET_KEY not set. Stripe payment features will not work.');
}

// Track processed sessions to prevent double-incrementing (idempotency)
const processedSessions = new Set();

// Middleware to check if Stripe is configured
const requireStripe = (req, res, next) => {
    if (!stripe) {
        return res.status(503).json({
            error: 'Payment service not configured. Please add STRIPE_SECRET_KEY to your .env file.'
        });
    }
    next();
};

// Price IDs - Create these in Stripe Dashboard
const STRIPE_PRICES = {
    STANDARD: process.env.STRIPE_STANDARD_PRICE_ID || null,
    PRO: process.env.STRIPE_PRO_PRICE_ID || null,
    PRO_ANNUAL: process.env.STRIPE_PRO_ANNUAL_PRICE_ID || null,
};

// Plan configuration with prices in paise for Stripe
const PLAN_PRICES = {
    STANDARD: { price: 29900, currency: 'inr', name: 'IntellPharma Standard', interval: 'month' },  // ₹299/mo
    PRO: { price: 49900, currency: 'inr', name: 'IntellPharma Pro', interval: 'month' },  // ₹499/mo
    PRO_ANNUAL: { price: 499900, currency: 'inr', name: 'IntellPharma Pro Annual', interval: 'year' },  // ₹4,999/yr
    EXTRA_BRANCH: { price: 49900, currency: 'inr', name: 'IntellPharma Extra Branch', interval: 'month' } // ₹499/mo
};

// Create or get Stripe customer for user
async function getOrCreateStripeCustomer(user) {
    // Check if user already has a Stripe customer ID
    if (user.stripeCustomerId) {
        try {
            const customer = await stripe.customers.retrieve(user.stripeCustomerId);
            if (!customer.deleted) {
                return customer;
            }
        } catch (error) {
            console.log('Customer not found, creating new one...');
        }
    }

    // Create new Stripe customer
    const customer = await stripe.customers.create({
        email: user.email,
        name: user.name,
        metadata: {
            userId: user.id
        }
    });

    // Save customer ID to user
    await prisma.user.update({
        where: { id: user.id },
        data: { stripeCustomerId: customer.id }
    });

    return customer;
}

// Add Extra Branches (Payment Integration)
router.post('/add-extra-branches', requireStripe, authenticate, authorize('OWNER'), async (req, res) => {
    try {
        const { count } = req.body;
        if (!count || count < 1) return res.status(400).json({ error: 'Invalid branch count' });

        const user = await prisma.user.findUnique({
            where: { id: req.user.id },
            include: {
                ownedBranches: {
                    include: { subscription: true }
                }
            }
        });

        const customer = await getOrCreateStripeCustomer(user);
        const planConfig = PLAN_PRICES.EXTRA_BRANCH;

        // Check for active subscription
        const subscriptions = await stripe.subscriptions.list({
            customer: customer.id,
            status: 'active',
            limit: 1
        });

        // Always redirect to Stripe Checkout for extra branches payment
        const session = await stripe.checkout.sessions.create({
            customer: customer.id,
            mode: 'subscription',
            line_items: [
                {
                    price_data: {
                        currency: planConfig.currency,
                        product_data: {
                            name: planConfig.name,
                            description: `${planConfig.name} - Monthly Subscription for ${count} branch(es)`,
                        },
                        recurring: { interval: 'month' },
                        unit_amount: planConfig.price,
                    },
                    quantity: count,
                },
            ],
            metadata: {
                userId: user.id,
                type: 'EXTRA_BRANCH_ONLY',
                count: String(count)
            },
            // Include type and count in success URL so frontend can immediately detect extra branch purchase
            success_url: `${process.env.CLIENT_URL || 'http://localhost:5173'}/payment-success?session_id={CHECKOUT_SESSION_ID}&type=extra_branch&count=${count}`,
            cancel_url: `${process.env.CLIENT_URL || 'http://localhost:5173'}/payment-cancel`,
            subscription_data: {
                metadata: {
                    userId: user.id,
                    type: 'EXTRA_BRANCH_ONLY',
                    count: String(count)
                }
            }
        });

        return res.json({ url: session.url });

    } catch (error) {
        console.error('Add extra branches error:', error);
        res.status(500).json({ error: error.message || 'Failed to process extra branch request.' });
    }
});

// Create Checkout Session for subscription
router.post('/create-checkout-session', requireStripe, authenticate, authorize('OWNER'), async (req, res) => {
    try {
        const { planId } = req.body;

        if (!planId || !PLAN_PRICES[planId]) {
            return res.status(400).json({ error: 'Invalid plan selected.' });
        }

        const planConfig = PLAN_PRICES[planId];

        // Get user with current subscription
        const user = await prisma.user.findUnique({
            where: { id: req.user.id },
            include: {
                ownedBranches: {
                    include: {
                        subscription: true
                    }
                }
            }
        });

        // Get or create Stripe customer
        const customer = await getOrCreateStripeCustomer(user);

        // Create Stripe Checkout Session
        const session = await stripe.checkout.sessions.create({
            customer: customer.id,
            payment_method_types: ['card'],
            mode: 'subscription',
            line_items: [
                {
                    price_data: {
                        currency: planConfig.currency,
                        product_data: {
                            name: planConfig.name,
                            description: `${planConfig.name} - ${planConfig.interval === 'year' ? 'Annual' : 'Monthly'} Subscription`,
                        },
                        recurring: {
                            interval: planConfig.interval,
                        },
                        unit_amount: planConfig.price,
                    },
                    quantity: 1,
                },
            ],
            metadata: {
                userId: user.id,
                planId: planId,
            },
            success_url: `${process.env.CLIENT_URL || 'http://localhost:5173'}/payment-success?session_id={CHECKOUT_SESSION_ID}`,
            cancel_url: `${process.env.CLIENT_URL || 'http://localhost:5173'}/payment-cancel`,
            subscription_data: {
                metadata: {
                    userId: user.id,
                    planId: planId,
                }
            }
        });

        res.json({
            sessionId: session.id,
            url: session.url
        });

    } catch (error) {
        console.error('Create checkout session error:', error);
        res.status(500).json({ error: 'Failed to create checkout session.' });
    }
});

// Get current subscription status from Stripe AND sync to local DB
router.get('/subscription-status', requireStripe, authenticate, authorize('OWNER'), async (req, res) => {
    try {
        const user = await prisma.user.findUnique({
            where: { id: req.user.id },
            include: {
                ownedBranches: {
                    include: {
                        subscription: true
                    }
                }
            }
        });

        if (!user.stripeCustomerId) {
            return res.json({
                hasSubscription: false,
                plan: 'STANDARD',
                status: 'free'
            });
        }

        // Get subscriptions from Stripe
        const subscriptions = await stripe.subscriptions.list({
            customer: user.stripeCustomerId,
            status: 'active',
            limit: 1
        });

        if (subscriptions.data.length === 0) {
            return res.json({
                hasSubscription: false,
                plan: 'STANDARD',
                status: 'free'
            });
        }

        const subscription = subscriptions.data[0];

        // Check if this is an extra branch subscription (no planId in metadata)
        const isExtraBranch = subscription.metadata?.type === 'EXTRA_BRANCH_ONLY';

        // For extra branch subscriptions, keep the current plan; otherwise use metadata or default
        let planId;
        if (isExtraBranch) {
            // Get current plan from database, don't override it
            const existingLocalSub = user.ownedBranches[0]?.subscription;
            planId = existingLocalSub?.plan || 'STANDARD';
        } else {
            planId = subscription.metadata?.planId || 'PRO';
        }

        // SYNC: Update local database if Stripe has active subscription
        if (user.ownedBranches.length > 0) {
            const branch = user.ownedBranches[0];
            const localSub = branch.subscription;
            const planConfig = PLANS[planId] || PLANS.STANDARD;

            // Safely parse the period end date
            const periodEndTimestamp = subscription.current_period_end;
            const periodEndDate = periodEndTimestamp
                ? new Date(periodEndTimestamp * 1000)
                : new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // Default to 30 days from now

            // Check if local DB is out of sync with Stripe (but not for extra branch subs)
            const needsSync = !isExtraBranch && (!localSub ||
                localSub.plan !== planId ||
                localSub.stripeSubscriptionId !== subscription.id);

            if (needsSync) {
                console.log(`🔄 Syncing subscription for user ${user.id}: ${localSub?.plan || 'NONE'} -> ${planId}`);

                await prisma.subscription.upsert({
                    where: { branchId: branch.id },
                    update: {
                        plan: planId,
                        isTrial: false,
                        maxBranches: planConfig.maxBranches,
                        aiEnabled: planConfig.aiEnabled,
                        analyticsEnabled: planConfig.analyticsEnabled,
                        stripeSubscriptionId: subscription.id,
                        stripePriceId: subscription.items?.data?.[0]?.price?.id || null,
                        stripeCurrentPeriodEnd: periodEndDate,
                        autoRenew: !subscription.cancel_at_period_end,
                        endDate: periodEndDate
                    },
                    create: {
                        branchId: branch.id,
                        plan: planId,
                        isTrial: false,
                        maxBranches: planConfig.maxBranches,
                        aiEnabled: planConfig.aiEnabled,
                        analyticsEnabled: planConfig.analyticsEnabled,
                        stripeSubscriptionId: subscription.id,
                        stripePriceId: subscription.items?.data?.[0]?.price?.id || null,
                        stripeCurrentPeriodEnd: periodEndDate,
                        autoRenew: !subscription.cancel_at_period_end,
                        endDate: periodEndDate
                    }
                });

                console.log(`✅ Subscription synced successfully to ${planId}`);
            }
        }

        res.json({
            hasSubscription: true,
            plan: planId,
            status: subscription.status,
            currentPeriodEnd: periodEndDate, // Use the safely parsed date
            cancelAtPeriodEnd: subscription.cancel_at_period_end,
            stripeSubscriptionId: subscription.id
        });

    } catch (error) {
        console.error('Get subscription status error:', error);
        res.status(500).json({ error: 'Failed to get subscription status.' });
    }
});

// Create Customer Portal session for managing billing
router.post('/create-portal-session', requireStripe, authenticate, authorize('OWNER'), async (req, res) => {
    try {
        const user = await prisma.user.findUnique({
            where: { id: req.user.id }
        });

        if (!user.stripeCustomerId) {
            return res.status(400).json({ error: 'No billing account found. Please subscribe first.' });
        }

        const portalSession = await stripe.billingPortal.sessions.create({
            customer: user.stripeCustomerId,
            return_url: `${process.env.CLIENT_URL || 'http://localhost:5173'}/subscription`,
        });

        res.json({ url: portalSession.url });

    } catch (error) {
        console.error('Create portal session error:', error);
        res.status(500).json({ error: 'Failed to create billing portal session.' });
    }
});

// Verify checkout session (called from success page)
router.get('/verify-session/:sessionId', requireStripe, authenticate, async (req, res) => {
    try {
        const { sessionId } = req.params;

        console.log('🔍 verify-session: Starting with sessionId:', sessionId);

        const session = await stripe.checkout.sessions.retrieve(sessionId, {
            expand: ['subscription', 'subscription.items']
        });

        console.log('🔍 verify-session: Session metadata:', session.metadata);
        console.log('🔍 verify-session: Payment status:', session.payment_status);

        if (session.payment_status === 'paid' && session.subscription) {
            const subscription = session.subscription;

            // Handle Extra Branch Only checkout
            console.log('🔍 verify-session: Checking metadata.type:', session.metadata?.type);
            if (session.metadata?.type === 'EXTRA_BRANCH_ONLY') {
                const count = parseInt(session.metadata.count || '0');
                console.log('✅ verify-session: EXTRA_BRANCH_ONLY detected! Count:', count);

                // Idempotency check - prevent processing same session twice
                if (processedSessions.has(sessionId)) {
                    console.log('⚠️ verify-session: Session already processed, skipping increment');
                    return res.json({
                        success: true,
                        type: 'EXTRA_BRANCH_ONLY',
                        count: count,
                        message: `Extra branch(es) already added!`,
                        alreadyProcessed: true
                    });
                }

                // Mark session as being processed
                processedSessions.add(sessionId);

                // Find user and update extraBranches
                const user = await prisma.user.findUnique({
                    where: { id: req.user.id },
                    include: { ownedBranches: { include: { subscription: true } } }
                });

                if (user.ownedBranches.length > 0) {
                    const branch = user.ownedBranches[0];
                    const existingSub = branch.subscription;
                    console.log('🔍 verify-session: Existing subscription:', existingSub);
                    console.log('🔍 verify-session: Current extraBranches:', existingSub?.extraBranches || 0);

                    // Update extraBranches and ensure stripeSubscriptionId is set
                    let updatedSub;
                    try {
                        const periodEnd = subscription.current_period_end
                            ? new Date(subscription.current_period_end * 1000)
                            : new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);

                        if (existingSub) {
                            // Subscription exists - increment extraBranches
                            // Also set stripeSubscriptionId if not already set (for Basic users)
                            const updateData = {
                                extraBranches: { increment: count },
                                autoRenew: true
                            };

                            // Only set stripe fields if not already present
                            if (!existingSub.stripeSubscriptionId) {
                                updateData.stripeSubscriptionId = subscription.id;
                                updateData.stripeCurrentPeriodEnd = periodEnd;
                            }

                            updatedSub = await prisma.subscription.update({
                                where: { branchId: branch.id },
                                data: updateData
                            });
                        } else {
                            // No subscription exists, create new one
                            updatedSub = await prisma.subscription.create({
                                data: {
                                    branchId: branch.id,
                                    plan: 'STANDARD',
                                    maxBranches: 1,
                                    extraBranches: count,
                                    stripeSubscriptionId: subscription.id,
                                    stripeCurrentPeriodEnd: periodEnd,
                                    autoRenew: true
                                }
                            });
                        }
                        console.log('✅ verify-session: Updated subscription extraBranches:', updatedSub.extraBranches);
                    } catch (dbError) {
                        console.error('❌ verify-session: Database update FAILED:', dbError);
                    }
                }

                return res.json({
                    success: true,
                    type: 'EXTRA_BRANCH_ONLY',
                    count: count,
                    message: `Successfully subscribed to ${count} extra branch(es)!`
                });
            }

            const planId = session.metadata?.planId;

            if (!planId) {
                console.error('Missing planId in session metadata:', session.id);
                // If specific type check failed and no planId, do NOT default to PRO.
                // It's better to fail safe.
                return res.status(400).json({ error: 'Invalid subscription session data.' });
            }

            // Update user's subscription in database
            const user = await prisma.user.findUnique({
                where: { id: req.user.id },
                include: {
                    ownedBranches: {
                        include: {
                            subscription: true
                        }
                    }
                }
            });

            if (user.ownedBranches.length > 0) {
                const branch = user.ownedBranches[0];

                // Get plan configuration from shared PLANS config
                const planConfig = PLANS[planId] || PLANS.STANDARD;

                // Update or create subscription
                await prisma.subscription.upsert({
                    where: { branchId: branch.id },
                    update: {
                        plan: planId,
                        isTrial: false,
                        maxBranches: planConfig.maxBranches,
                        aiEnabled: planConfig.aiEnabled,
                        analyticsEnabled: planConfig.analyticsEnabled,
                        stripeSubscriptionId: subscription.id,
                        stripePriceId: subscription.items.data[0]?.price?.id,
                        stripeCurrentPeriodEnd: new Date(subscription.current_period_end * 1000),
                        autoRenew: !subscription.cancel_at_period_end,
                        endDate: new Date(subscription.current_period_end * 1000)
                    },
                    create: {
                        branchId: branch.id,
                        plan: planId,
                        isTrial: false,
                        maxBranches: planConfig.maxBranches,
                        aiEnabled: planConfig.aiEnabled,
                        analyticsEnabled: planConfig.analyticsEnabled,
                        stripeSubscriptionId: subscription.id,
                        stripePriceId: subscription.items.data[0]?.price?.id,
                        stripeCurrentPeriodEnd: new Date(subscription.current_period_end * 1000),
                        autoRenew: !subscription.cancel_at_period_end,
                        endDate: new Date(subscription.current_period_end * 1000)
                    }
                });
            }

            res.json({
                success: true,
                plan: planId,
                message: `Successfully subscribed to ${planId} plan!`
            });
        } else {
            res.json({
                success: false,
                message: 'Payment not completed or subscription not found.'
            });
        }

    } catch (error) {
        console.error('Verify session error:', error);
        res.status(500).json({ error: 'Failed to verify session.' });
    }
});

// Stripe Webhook handler (raw body required)
router.post('/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
    const sig = req.headers['stripe-signature'];
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

    let event;

    try {
        if (webhookSecret) {
            event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
        } else {
            // For testing without webhook signature verification
            event = JSON.parse(req.body);
            console.warn('⚠️  Webhook signature verification skipped (no STRIPE_WEBHOOK_SECRET set)');
        }
    } catch (err) {
        console.error('Webhook signature verification failed:', err.message);
        return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    // Handle the event
    switch (event.type) {
        case 'checkout.session.completed': {
            const session = event.data.object;
            console.log('✅ Checkout session completed:', session.id);

            // The subscription is created, but we'll update via verify-session endpoint
            // or handle it here for webhook-first approach
            break;
        }

        case 'customer.subscription.updated': {
            const subscription = event.data.object;
            console.log('📝 Subscription updated:', subscription.id);

            // Update subscription in database
            await prisma.subscription.updateMany({
                where: { stripeSubscriptionId: subscription.id },
                data: {
                    autoRenew: !subscription.cancel_at_period_end,
                    stripeCurrentPeriodEnd: new Date(subscription.current_period_end * 1000),
                    endDate: new Date(subscription.current_period_end * 1000)
                }
            });
            break;
        }

        case 'customer.subscription.deleted': {
            const subscription = event.data.object;
            console.log('❌ Subscription cancelled:', subscription.id);

            // Downgrade to BASIC plan
            await prisma.subscription.updateMany({
                where: { stripeSubscriptionId: subscription.id },
                data: {
                    plan: 'STANDARD',
                    maxBranches: 1,
                    aiEnabled: false,
                    analyticsEnabled: false,
                    stripeSubscriptionId: null,
                    stripePriceId: null,
                    stripeCurrentPeriodEnd: null,
                    autoRenew: false
                }
            });
            break;
        }

        case 'invoice.payment_succeeded': {
            const invoice = event.data.object;
            console.log('💰 Payment succeeded for invoice:', invoice.id);
            break;
        }

        case 'invoice.payment_failed': {
            const invoice = event.data.object;
            console.log('⚠️  Payment failed for invoice:', invoice.id);
            // Could send email notification here
            break;
        }

        default:
            console.log(`Unhandled event type: ${event.type}`);
    }

    res.json({ received: true });
});

module.exports = router;
